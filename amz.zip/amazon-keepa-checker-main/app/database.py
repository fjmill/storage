from dataclasses import dataclass
from typing import List

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


@dataclass(frozen=True)
class ChatData:
    chat_id: int
    folder_id: str
    upc_table_id: str
    chat_type: str

    def __hash__(self):
        return hash((self.chat_id, self.folder_id, self.upc_table_id, self.chat_type))


@dataclass
class Chat(db.Model):
    chat_id: int
    folder_id: str
    upc_table_id: str
    chat_type: str
    __tablename__ = 'chats'

    id = db.Column(db.Integer, primary_key=True)
    chat_id = db.Column(db.BigInteger)
    folder_id = db.Column(db.String)
    upc_table_id = db.Column(db.String, nullable=True)
    chat_type = db.Column(db.String)

    admins = db.relationship('Admin', back_populates='chat', cascade='all, delete-orphan')
    google_tables = db.relationship('ChatGoogleTable', back_populates='chat', cascade='all, delete-orphan')

    def get_data(self) -> ChatData:
        return ChatData(
            chat_id=self.chat_id,
            folder_id=self.folder_id,
            upc_table_id=self.upc_table_id,
            chat_type=self.chat_type
        )


@dataclass
class Admin(db.Model):
    __tablename__ = 'admins'

    id = db.Column(db.Integer, primary_key=True)
    chat_id = db.Column(db.Integer, db.ForeignKey('chats.id'))
    admin_id = db.Column(db.Integer)

    chat = db.relationship('Chat', back_populates='admins')


@dataclass
class ChatGoogleTable(db.Model):
    id: int
    google_table_id: str
    __tablename__ = 'chat_google_tables'

    id = db.Column(db.Integer, primary_key=True)
    chat_id = db.Column(db.Integer, db.ForeignKey('chats.id'))
    google_table_id = db.Column(db.String)

    chat = db.relationship('Chat', back_populates='google_tables')


class Database:
    def __init__(self, app):
        self.db = db
        self.db.init_app(app)

        with app.app_context():
            self.db.create_all()

    def commit_changes(self):
        self.db.session.commit()

    def add_chat(self, chat_data):
        chat = Chat(**chat_data)
        self.db.session.add(chat)
        self.db.session.commit()
        return chat

    def add_admin(self, admin_data):
        admin = Admin(**admin_data)
        self.db.session.add(admin)
        self.db.session.commit()

    def add_chat_google_table(self, chat_google_table_data):
        chat_google_table = ChatGoogleTable(**chat_google_table_data)
        self.db.session.add(chat_google_table)
        self.db.session.commit()

    def remove_chat(self, chat_id):
        chat = Chat.query.get(chat_id)
        if chat:
            self.db.session.delete(chat)
            self.db.session.commit()

    def remove_admin(self, admin_id):
        admin = Admin.query.get(admin_id)
        if admin:
            self.db.session.delete(admin)
            self.db.session.commit()

    def remove_chat_google_table(self, chat_google_table_id):
        chat_google_table = ChatGoogleTable.query.get(chat_google_table_id)
        if chat_google_table:
            self.db.session.delete(chat_google_table)
            self.db.session.commit()

    def get_all_chats(self) -> List[Chat]:
        return Chat.query.all()

    def get_all_admins(self) -> List[Admin]:
        return Admin.query.all()

    def get_all_chat_google_tables(self) -> List[ChatGoogleTable]:
        return ChatGoogleTable.query.all()

    def get_chat_by_id(self, chat_id):
        return Chat.query.get(chat_id)

    def get_chat_by_chat_id(self, chat_id):
        return Chat.query.filter_by(chat_id=chat_id).first()

    def get_chats_by_google_table_id(self, google_table_id) -> List[Chat]:
        return Chat.query.join(Chat.google_tables).filter(ChatGoogleTable.google_table_id == google_table_id).all()

    def get_admin_by_id(self, admin_id):
        return Admin.query.get(admin_id)

    def get_chat_google_table_by_id(self, chat_google_table_id):
        return ChatGoogleTable.query.get(chat_google_table_id)

    def get_chat_google_table_by_id_and_chat_id(self, chat_id, chat_google_table_id):
        return ChatGoogleTable.query.filter_by(chat_id=chat_id, id=chat_google_table_id).first()

    def get_chat_google_table_by_table_id_and_chat_id(self, chat_id, google_table_id):
        return ChatGoogleTable.query.filter_by(google_table_id=google_table_id, chat_id=chat_id).first()

    def get_unique_chat_google_tables(self) -> List[ChatGoogleTable]:
        return ChatGoogleTable.query.distinct(ChatGoogleTable.google_table_id).all()
