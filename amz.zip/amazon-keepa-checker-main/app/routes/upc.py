import os

from flask import request, jsonify, Blueprint
from jsonschema import validate, ValidationError

from app import app_database
from app.utils.google_api import get_service_email
from app.utils.google_sheets import get_google_sheet_data

upc_blueprint = Blueprint('upc_blueprint', __name__)


@upc_blueprint.route('', methods=['POST'])
def add_tracked_table():
    schema = {
        "type": "object",
        "properties": {
            "chat_id": {"type": "integer"},
            "user_id": {"type": "integer"},
            "table_id": {"type": "string"}
        },
        "required": ["chat_id", "user_id", "table_id"]
    }

    if request.method == 'POST':
        table_data = request.json

        try:
            validate(instance=table_data, schema=schema)
        except ValidationError as e:
            return jsonify({'error': str(e)}), 400

        chat_id = table_data['chat_id']
        user_id = table_data['user_id']
        table_id = table_data['table_id']

        try:
            get_google_sheet_data(table_id, os.getenv('DEFAULT_UPC_WORKSHEET'))
        except Exception as e:
            return jsonify({'error': str(e), 'email': get_service_email()}), 423

        chat = app_database.get_chat_by_chat_id(chat_id)

        if chat is None:
            return jsonify({'error': f"Chat with id {chat_id} isn't registered"}), 404

        chat.upc_table_id = table_id
        app_database.commit_changes()

        return jsonify({"chat": chat, "tables": chat.google_tables})


@upc_blueprint.route('', methods=['DELETE'])
def remove_tracked_table():
    schema = {
        "type": "object",
        "properties": {
            "chat_id": {"type": "integer"},
            "user_id": {"type": "integer"}
        },
        "required": ["chat_id", "user_id"]
    }

    if request.method == 'DELETE':
        table_data = request.json

        try:
            validate(instance=table_data, schema=schema)
        except ValidationError as e:
            return jsonify({'error': str(e)}), 400

        chat_id = table_data['chat_id']
        user_id = table_data['user_id']

        chat = app_database.get_chat_by_chat_id(chat_id)

        if chat is None:
            return jsonify({'error': f"Chat with id {chat_id} isn't registered"}), 404

        if chat.upc_table_id is None:
            return jsonify({'error': f"UPC table for chat with id {chat_id} isn't set"}), 409

        chat.upc_table_id = None
        app_database.commit_changes()

        return jsonify({"chat": chat, "tables": chat.google_tables})
