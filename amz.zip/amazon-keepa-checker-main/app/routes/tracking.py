import os

from flask import request, jsonify, Blueprint
from jsonschema import validate, ValidationError

from app import app_database
from app.utils.google_api import get_service_email
from app.utils.google_sheets import get_google_sheet_data

tracking_blueprint = Blueprint('tracking_blueprint', __name__)


@tracking_blueprint.route('/tracked', methods=['GET'])
def get_group_tracked():
    if request.method == 'GET':
        chat_id = request.args.get('chat_id')

        if chat_id is None:
            return jsonify({'error': 'Missing chat_id in request data'}), 400
        else:
            try:
                chat_id = int(chat_id)
            except ValueError:
                return jsonify({'error': 'chat_id must be an integer'}), 400

        chat = app_database.get_chat_by_chat_id(chat_id)

        if chat is None:
            return jsonify({'error': f"Chat with id {chat_id} isn't registered"}), 404

        return jsonify({"chat": chat, "tables": chat.google_tables})


@tracking_blueprint.route('/add_table', methods=['POST'])
def add_tracked_table():
    schema = {
        "type": "object",
        "properties": {
            "chat_id": {"type": "integer"},
            "user_id": {"type": "integer"},
            "table_id": {"type": "string"}
        },
        "required": ["chat_id", "user_id", "table_id"]
    }

    if request.method == 'POST':
        table_data = request.json

        try:
            validate(instance=table_data, schema=schema)
        except ValidationError as e:
            return jsonify({'error': str(e)}), 400

        chat_id = table_data['chat_id']
        user_id = table_data['user_id']
        table_id = table_data['table_id']

        try:
            get_google_sheet_data(table_id, os.getenv('DEFAULT_ASIN_WORKSHEET'))
        except Exception as e:
            return jsonify({'error': str(e), 'email': get_service_email()}), 423

        chat = app_database.get_chat_by_chat_id(chat_id)

        if chat is None:
            return jsonify({'error': f"Chat with id {chat_id} isn't registered"}), 404

        table = app_database.get_chat_google_table_by_table_id_and_chat_id(chat.id, table_id)

        if table is not None:
            return jsonify({'error': f"Table with id {table_id} is already tracked"}), 409

        app_database.add_chat_google_table({
            'chat_id': chat.id,
            'google_table_id': table_id
        })

        return jsonify({"chat": chat, "tables": chat.google_tables})


@tracking_blueprint.route('/remove_table', methods=['POST'])
def remove_tracked_table():
    schema = {
        "type": "object",
        "properties": {
            "chat_id": {"type": "integer"},
            "user_id": {"type": "integer"},
            "table_id": {"type": "integer"}
        },
        "required": ["chat_id", "user_id", "table_id"]
    }

    if request.method == 'POST':
        table_data = request.json

        try:
            validate(instance=table_data, schema=schema)
        except ValidationError as e:
            return jsonify({'error': str(e)}), 400

        chat_id = table_data['chat_id']
        user_id = table_data['user_id']
        table_id = table_data['table_id']

        chat = app_database.get_chat_by_chat_id(chat_id)

        if chat is None:
            return jsonify({'error': f"Chat with id {chat_id} isn't registered"}), 404

        table = app_database.get_chat_google_table_by_id_and_chat_id(chat.id, table_id)

        if table is None:
            return jsonify({'error': f"Table with id {table_id} is not tracked by your chat"}), 409

        app_database.remove_chat_google_table(table.id)

        return jsonify({"chat": chat, "tables": chat.google_tables})
