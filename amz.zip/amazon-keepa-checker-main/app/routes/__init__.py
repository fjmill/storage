from .register import register_blueprint as register
from .tracking import tracking_blueprint as tracking
from .upc import upc_blueprint as upc
