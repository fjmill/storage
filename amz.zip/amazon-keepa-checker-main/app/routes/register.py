from flask import request, jsonify, Blueprint
from jsonschema import validate, ValidationError
from app import app_database
from app.utils.utilities import create_folder_for_chat, delete_drive_folder

register_blueprint = Blueprint('register_blueprint', __name__)


@register_blueprint.route('/register_group', methods=['POST'])
def register_group():
    schema = {
        "type": "object",
        "properties": {
            "chat_id": {"type": "integer"},
            "type": {"type": "string", "enum": ["private", "group"]}
        },
        "required": ["chat_id", "type"]
    }

    if request.method == 'POST':
        chat_data = request.json

        try:
            validate(instance=chat_data, schema=schema)
        except ValidationError as e:
            return jsonify({'error': str(e)}), 400

        chat = app_database.get_chat_by_chat_id(chat_data['chat_id'])

        if chat is not None:
            return jsonify({'error': f"Already registered"}), 403

        folder_id = create_folder_for_chat(chat_data['chat_id'])

        chat = app_database.add_chat({
            'chat_id': chat_data['chat_id'],
            'folder_id': folder_id,
            'chat_type': chat_data['type']
        })

        return jsonify(chat)


@register_blueprint.route('/unregister_group', methods=['POST'])
def unregister_group():
    schema = {
        "type": "object",
        "properties": {
            "chat_id": {"type": "integer"},
            "user_id": {"type": "integer"}
        },
        "required": ["chat_id"]
    }

    if request.method == 'POST':
        chat_data = request.json

        try:
            validate(instance=chat_data, schema=schema)
        except ValidationError as e:
            return jsonify({'error': str(e)}), 400

        chat = app_database.get_chat_by_chat_id(chat_data['chat_id'])

        if chat is None:
            return jsonify({'error': f"Chat with id {chat_data['chat_id']} isn't registered"}), 404
        else:
            delete_drive_folder(chat.folder_id)
            app_database.remove_chat(chat.id)

        return jsonify(chat)

