import os
from dotenv import load_dotenv

from flask import Flask
from flask_apscheduler import APScheduler

from .database import Database

load_dotenv()

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL")
app_database = Database(app)
scheduler = APScheduler()
