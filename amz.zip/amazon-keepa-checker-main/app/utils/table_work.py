import openpyxl


def find_column_with_keywords(sheet, keyword):
    for col in range(1, sheet.max_column + 1):
        cell_value = str(sheet.cell(2, col).value)
        if keyword == cell_value:
            return col

    return None


def update_1ca(asin, path, upcs):
    wb = openpyxl.load_workbook(path)
    sheet = wb['Template']

    seller_sku_column = find_column_with_keywords(sheet, 'Seller SKU')
    product_id_column = find_column_with_keywords(sheet, 'Product ID')

    if seller_sku_column is not None:
        asins = [f'{asin}-{i + 1}' for i in range(3)]
        for i, value in enumerate(asins):
            sheet.cell(i + 3 + 1, seller_sku_column).value = value

    if product_id_column is not None:
        for i, value in enumerate(upcs):
            sheet.cell(i + 3 + 1, product_id_column).value = value

    wb.save(path)


def update_2us(asin, path):
    wb = openpyxl.load_workbook(path)
    sheet = wb['Template']

    seller_sku_column = find_column_with_keywords(sheet, 'Seller SKU')
    parent_sku_column = find_column_with_keywords(sheet, 'Parent SKU')

    if seller_sku_column is not None:
        asins = [f'{asin}-p'] + [f'{asin}-{i + 1}' for i in range(3)]
        for i, value in enumerate(asins):
            sheet.cell(i + 3 + 1, seller_sku_column).value = value

    if parent_sku_column is not None:
        for i in range(3):
            sheet.cell(i + 4 + 1, parent_sku_column).value = f'{asin}-p'

    wb.save(path)


def update_3ca(asin, path):
    wb = openpyxl.load_workbook(path)
    sheet = wb['Template']

    seller_sku_column = find_column_with_keywords(sheet, 'Seller SKU')

    if seller_sku_column is not None:
        needed_row_index = 4
        while sheet.cell(needed_row_index, seller_sku_column).value in ['', None]:
            needed_row_index += 1

        sheet.cell(needed_row_index, seller_sku_column).value = f'{asin}-1'

    wb.save(path)


def update_4ca(asin, path):
    wb = openpyxl.load_workbook(path)
    sheet = wb['Template']

    seller_sku_column = find_column_with_keywords(sheet, 'Seller SKU')

    if seller_sku_column is not None:
        asins = [f'{asin}-{1}']
        for i, value in enumerate(asins):
            sheet.cell(i + 3 + 1, seller_sku_column).value = value

    wb.save(path)


def update_parent(asin, path, upc):
    wb = openpyxl.load_workbook(path)

    sheet = wb['Template']

    seller_sku_column = find_column_with_keywords(sheet, 'Seller SKU')

    product_id_column = find_column_with_keywords(sheet, 'Product ID')

    if seller_sku_column is not None:
        sheet.cell(4, seller_sku_column).value = f'{asin}-p'

    if product_id_column is not None:
        sheet.cell(4, product_id_column).value = upc

    wb.save(path)
