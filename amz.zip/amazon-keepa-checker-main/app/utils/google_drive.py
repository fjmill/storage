import io
import os

from googleapiclient.http import MediaIoBaseDownload, MediaFileUpload

from app.utils.google_api import get_drive


def get_file_in_folder(folder_id, file_name):
    drive = get_drive()
    response = drive.files().list(
        q=f"'{folder_id}' in parents and trashed=false and name = '{file_name}'",
        fields='files(id, name, webViewLink)'
    ).execute()
    if response.get('files'):
        file_id = response.get('files')[0]['id']
        file = drive.files().get(fileId=file_id).execute()
        return file['id'], f'https://drive.google.com/file/d/{file_id}/view'
    else:
        return None, None


def download_temporary_file(file_id, file_name, download_dir):
    drive = get_drive()
    request = drive.files().get_media(fileId=file_id)
    path = os.path.join(download_dir, file_name)
    fh = io.FileIO(path, 'wb')
    downloader = MediaIoBaseDownload(fh, request)
    done = False
    while done is False:
        status, done = downloader.next_chunk()
    return path


def update_existing_file(file_id, file_name):
    drive = get_drive()

    print(file_name)
    print(os.path.basename(file_name))

    file_metadata = {
        'name': os.path.basename(file_name),
    }
    media = MediaFileUpload(file_name, resumable=True)
    file = drive.files().update(fileId=file_id, body=file_metadata, media_body=media).execute()

    print(file)
