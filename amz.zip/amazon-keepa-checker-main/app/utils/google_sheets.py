import gspread

from app.utils.google_api import get_client
from app.utils.utilities import get_cell_range


def get_google_sheet_data(spreadsheet_id, sheet_name):
    client = get_client()  # Assume get_client is defined in google_api.py
    try:
        sheet = client.open_by_key(spreadsheet_id).worksheet(sheet_name)
        data = sheet.get_all_values()
        return data
    except gspread.exceptions.SpreadsheetNotFound:
        print(f"Spreadsheet {spreadsheet_id} not found.")
        raise Exception(f'Spreadsheet with id {spreadsheet_id} not found.')
    except gspread.exceptions.WorksheetNotFound:
        print(f"Worksheet {sheet_name} not found.")
        raise Exception(f'Worksheet with name {sheet_name} not found is Spreadsheet with id {spreadsheet_id}.')
    except Exception as e:
        print(f"An error occurred: {e}")
        raise Exception(f'An error occurred: {e}')


def update_google_sheet_data(spreadsheet_id, sheet_name, data):
    client = get_client()  # Assume get_client is defined in google_api.py
    try:
        sheet = client.open_by_key(spreadsheet_id).worksheet(sheet_name)
        sheet.clear()

        cell_range = get_cell_range(data)  # Assuming get_cell_range is in utilities.py
        sheet.update(cell_range, data)
    except gspread.exceptions.SpreadsheetNotFound:
        print(f"Spreadsheet {spreadsheet_id} not found.")
        raise Exception(f'Spreadsheet with id {spreadsheet_id} not found.')
    except gspread.exceptions.WorksheetNotFound:
        print(f"Worksheet {sheet_name} not found.")
        raise Exception(f'Worksheet with name {sheet_name} not found is Spreadsheet with id {spreadsheet_id}.')
    except Exception as e:
        print(f"An error occurred: {e}")
        raise Exception(f'An error occurred: {e}')
