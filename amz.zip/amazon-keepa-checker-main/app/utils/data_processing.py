import os
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor

import requests

from app.utils.google_drive import get_file_in_folder, download_temporary_file, update_existing_file
from app.utils.google_sheets import get_google_sheet_data, update_google_sheet_data
from app.utils.keepa_api import get_asins_info
from app.utils.table_work import update_1ca, update_2us, update_3ca, update_4ca, update_parent
from app.utils.utilities import generate_new_asin, extract_zip, zip_folder


def transform_data(initial_data):
    transformed_data = {
        "table_number": initial_data['table_number'],
        "table_id": initial_data['table_id'],
        "failed": [
            {
                "asin": item[0],
                "required": item[1],
                "real": item[2],
                "link": item[3],
                "success": item[4],
            } if len(item) > 3 else {
                "asin": item[0],
                "required": item[1],
                "real": item[2],
                "link": None,
                "success": 3,
            }
            for item in initial_data['failed']
        ],
        "check_upc": initial_data.get('check_upc', False),
        "unsetted_upc": 'check_upc' not in initial_data
    }
    return transformed_data


def split_and_pad(array, count_in_line=5):
    split_array = [array[i:i + count_in_line] for i in range(0, len(array), count_in_line)]

    if len(split_array[-1]) < count_in_line:
        split_array[-1] += [''] * (count_in_line - len(split_array[-1]))

    return split_array


def fix_template(folder_id, fail, new_upcs):
    temp_dir = tempfile.mkdtemp()

    asin = fail[0]
    file_name = f'{asin}.zip'
    need_to_upload = 0
    timer = time.time()
    file_id, link = get_file_in_folder(folder_id, file_name)

    if new_upcs is None:
        need_to_upload = 3
    else:
        if file_id:
            asin_archive = download_temporary_file(file_id, file_name, temp_dir)
            tables_dir = os.path.join(temp_dir, 'tables')
            os.mkdir(tables_dir)
            extract_zip(asin_archive, tables_dir)

            if os.path.exists(asin_archive):
                os.remove(asin_archive)

            tables_list = os.listdir(tables_dir)
            new_asin = generate_new_asin(asin)

            tables = {}

            for table_name in ['1CA', '2US', '3CA', '4CA', 'parent1', 'parent2']:
                for item in tables_list:
                    if item.startswith(table_name):
                        tables[table_name] = os.path.join(tables_dir, item)
                        break

            funcs = [
                lambda: update_1ca(new_asin, tables['1CA'], new_upcs[:3]),
                lambda: update_2us(new_asin, tables['2US']),
                lambda: update_3ca(new_asin, tables['3CA']),
                lambda: update_4ca(new_asin, tables['4CA']),
                lambda: update_parent(new_asin, tables['parent1'], new_upcs[-2]),
                lambda: update_parent(new_asin, tables['parent2'], new_upcs[-1]),
            ]

            with ThreadPoolExecutor(max_workers=len(funcs)) as executor:
                # Запуск функций в потоках
                futures = {executor.submit(func): func.__name__ for func in funcs}

                # Дожидаемся завершения всех задач
                for future in futures:
                    function_name = futures[future]
                    try:
                        result = future.result()
                    except Exception as e:
                        need_to_upload = 2
                        print(f"{function_name} вызвало исключение: {e}")

            print('NEED TO UPLOAD', need_to_upload)

            if need_to_upload == 0:
                zip_folder(tables_dir, asin_archive)
                update_existing_file(file_id, asin_archive)
        else:
            need_to_upload = 1

    timer = time.time() - timer

    fail = fail + (link, need_to_upload, timer,)

    return fail


def get_failed_asins_from_table(spreadsheet_id):
    data = get_google_sheet_data(spreadsheet_id, os.getenv('DEFAULT_ASIN_WORKSHEET'))
    failed_asins = []

    asins_reviews = {}

    for row in data:
        try:
            asins_reviews[row[0]] = int(row[1])
        except ValueError:
            asins_reviews[row[0]] = 0

    real_asins_reviews = get_asins_info(list(asins_reviews.keys()))

    for asin in asins_reviews.keys():
        needed = asins_reviews[asin]
        count = real_asins_reviews[asin]

        if needed > count:
            failed_asins.append((asin, needed, count))

    return failed_asins


def update_templates(chats):
    need_to_notify_chats = {}

    for chat in chats:
        if chat.upc_table_id is not None:
            upcs = get_upc_list_from_table(chat.upc_table_id)
            tables = chats[chat]
            need_to_notify = False

            for table in tables:
                failed = []
                for fail in table['failed']:
                    if len(upcs) > 5:
                        fixed = fix_template(chat.folder_id, fail, upcs[-5:])
                        if fixed[4] == 0:
                            upcs = upcs[:-5]
                    else:
                        fixed = fix_template(chat.folder_id, fail, None)

                    need_to_notify = True
                    failed.append(fixed)

                table['failed'] = failed

                if len(upcs) < 100:
                    table['check_upc'] = True
                else:
                    table['check_upc'] = False

            if need_to_notify:
                need_to_notify_chats[chat] = chats[chat]

            rewrite_upc_table(chat.upc_table_id, upcs)

    return need_to_notify_chats


def notify_chats(chats):
    chat_to_send = []

    for chat in chats:
        tables = [transform_data(table) for table in chats[chat]]
        need_upc_checking = any(table['check_upc'] for table in tables)
        unsetted_upc = any(table['unsetted_upc'] for table in tables)
        chat_to_send.append({
            "id": chat.chat_id,
            "tables": tables,
            "need_upc_checking": need_upc_checking,
            "unsetted_upc": unsetted_upc,
        })

    requests.post(f'{os.getenv("BOT_URL")}/notify', json={"chats": chat_to_send})


def get_upc_list_from_table(spreadsheet_id):
    data = get_google_sheet_data(spreadsheet_id, os.getenv('DEFAULT_UPC_WORKSHEET'))
    data = [upc for row in data for upc in row if upc != '']
    return data


def rewrite_upc_table(spreadsheet_id: str, upcs: list):
    update_google_sheet_data(spreadsheet_id, os.getenv('DEFAULT_UPC_WORKSHEET'), split_and_pad(upcs))
