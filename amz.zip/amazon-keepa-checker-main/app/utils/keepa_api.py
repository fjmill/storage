import os

import requests


def get_keepa_key():
    key = os.environ.get('KEEPA_KEY')
    return key


def get_asins_info(asins):
    keepa_key = get_keepa_key()
    response = requests.get(
        'https://api.keepa.com/product',
        params={
            'key': keepa_key,
            'domain': 1,
            'asin': ','.join(asins),
            'rating': 1,
        }
    )

    if response.ok:
        data = response.json()
        asins_reviews = dict()

        for product in data['products']:
            asins_reviews[product['asin']] = product['csv'][17][-1]

        return asins_reviews
    else:
        print(response.status_code)
        print(response.json())

    return {}
