import hashlib
import os
import random
import string
import zipfile

from googleapiclient.errors import HttpError

from app.utils.google_api import get_drive


def get_cell_range(data):
    rows = len(data)
    cols = len(data[0]) if rows > 0 else 0

    if rows == 0 or any(len(row) != cols for row in data):
        raise ValueError("Массив должен быть непустым и содержать строки одинаковой длины")

    start_row = 1
    start_col = 1

    end_row = start_row + rows - 1
    end_col = start_col + cols - 1

    start_col_letter = chr(ord('A') + start_col - 1)
    end_col_letter = chr(ord('A') + end_col - 1)

    cell_range = f"{start_col_letter}{start_row}:{end_col_letter}{end_row}"
    return cell_range


def create_folder_for_chat(chat_id):
    drive = get_drive()  # Assuming get_drive is defined in google_api.py
    folder_name = hashlib.sha1(f'{chat_id}'.encode()).hexdigest()

    file_metadata = {
        'name': folder_name,
        'mimeType': 'application/vnd.google-apps.folder',
    }
    file = drive.files().create(body=file_metadata, fields='id').execute()
    folder_id = file.get('id')

    permission = {
        'type': 'anyone',
        'role': 'writer',
    }

    drive.permissions().create(
        fileId=folder_id,
        body=permission,
        supportsAllDrives=True,
        sendNotificationEmail=False
    ).execute()

    print('Создана новая папка с ID:', folder_id)
    return folder_id


def delete_drive_folder(folder_id):
    drive = get_drive()  # Assuming get_drive is defined in google_api.py

    if folder_id:
        try:
            drive.files().delete(fileId=folder_id).execute()
            print("Папка успешно удалена")
        except HttpError as e:
            print("Ошибка при удалении папки:", e)
    else:
        print("Не удалось получить ID созданной папки")


def generate_new_asin(asin):
    # random_part_length = random.randint(1, 5)  # Случайная длина для новой части
    random_part_length = 5
    random_part = ''.join(random.choices(
        string.ascii_letters + string.digits,
        k=random_part_length
    ))  # Случайные буквы и цифры
    new_asin = f"{asin}-{random_part}"  # Генерация нового asin
    return new_asin


def extract_zip(file_name, folder):
    with zipfile.ZipFile(file_name, 'r') as zip_ref:
        zip_ref.extractall(folder)


def zip_folder(folder_path, output_path):
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, folder_path))
