import os
from googleapiclient.discovery import build
from oauth2client.service_account import ServiceAccountCredentials
import gspread


def get_credentials():
    scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    creds = ServiceAccountCredentials.from_json_keyfile_name(os.getenv('CREDS_PATH'), scope)
    return creds


def get_client():
    creds = get_credentials()
    client = gspread.authorize(creds)
    return client


def get_drive():
    creds = get_credentials()
    drive_service = build('drive', 'v3', credentials=creds)
    return drive_service


def get_service_email():
    creds = get_credentials()
    email = creds.service_account_email
    return email
