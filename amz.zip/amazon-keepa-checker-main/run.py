import os
import time

from app import app, scheduler, app_database
from app.routes import register, tracking, upc
from app.utils.data_processing import update_templates, get_failed_asins_from_table, notify_chats


@scheduler.task('interval', minutes=1)
def check_asins_by_keepa():
    with scheduler.app.app_context():
        tables = app_database.get_unique_chat_google_tables()
        chats_to_notify = {}

        for table in tables:
            chats = app_database.get_chats_by_google_table_id(table.google_table_id)
            failed_asins = get_failed_asins_from_table(table.google_table_id)

            for chat in chats:
                chats_to_notify.setdefault(chat.get_data(), []).append({
                    "table_number": table.id,
                    "table_id": table.google_table_id,
                    "failed": failed_asins,
                })

        chats_to_notify = update_templates(chats_to_notify)

    notify_chats(chats_to_notify)


def print_routes():
    routes = []
    for rule in app.url_map.iter_rules():
        route = {
            'endpoint': rule.endpoint,
            'methods': ','.join(rule.methods),
            'path': str(rule)
        }
        routes.append(route)
    return routes


def display_routes():
    routes = print_routes()
    print("Список доступных роутов:")
    for route in routes:
        print(f"Endpoint: {route['endpoint']}, Методы: {route['methods']}, Путь: {route['path']}")


if __name__ == "__main__":
    app.register_blueprint(register, url_prefix="/auth")
    app.register_blueprint(tracking, url_prefix="/track")
    app.register_blueprint(upc, url_prefix="/upc")
    scheduler.init_app(app)
    scheduler.start()
    # display_routes()
    print(f'{os.getenv("BOT_URL")}/notify')
    app.run()
