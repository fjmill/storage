from typing import Generic, TypeVar

_T = TypeVar('_T')


class Response(Generic[_T]):
    def __init__(self, success: bool, data: _T = None, message: str = None):
        self.success = success
        self.message = message
        self.data = data

    @classmethod
    def ok(cls, data: _T = None):
        return cls(True, data=data)

    @classmethod
    def error(cls, message):
        return cls(False, message=message)
