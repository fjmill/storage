class GoogleTable:
    id: int
    google_table_id: str

    def __init__(self, id: int, google_table_id: str):
        self.id = id
        self.google_table_id = google_table_id

    def get_link(self) -> str:
        base_url = "https://docs.google.com/spreadsheets/d/"
        return f"{base_url}{self.google_table_id}"

    @staticmethod
    def get_link_from_id(table_id) -> str:
        base_url = "https://docs.google.com/spreadsheets/d/"
        return f"{base_url}{table_id}"
