from aiogram import Router

admins_router = Router()
