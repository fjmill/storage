from .admins import admins_router
from .auth import auth_router
from .settings import settings_router
from .tables import tables_router
from .upc import upc_router
