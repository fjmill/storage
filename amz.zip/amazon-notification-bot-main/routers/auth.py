from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from utils import register_group, unregister_group

auth_router = Router()


@auth_router.message(Command("register"))
async def register_handler(msg: Message):
    chat_id = msg.chat.id
    chat_type = "private" if msg.chat.type == "private" else "group"
    user_id = msg.from_user.id

    result = register_group(chat_id, chat_type, user_id)

    await msg.answer(result.message)


@auth_router.message(Command("unregister"))
async def unregister_handler(msg: Message):
    chat_id = msg.chat.id
    user_id = msg.from_user.id

    result = unregister_group(chat_id, user_id)

    await msg.answer(result.message)
