from aiogram import Router
from aiogram.filters import Command, CommandObject
from aiogram.types import Message

from enums import BotMessage
from utils import get_tracked_tables, extract_spreadsheet_id, add_table, remove_table, get_folder_url

tables_router = Router()


@tables_router.message(Command("tracked"))
async def get_tracked_tables_handler(msg: Message):
    chat_id = msg.chat.id

    result = get_tracked_tables(chat_id)

    if result.success:
        if len(result.data[2]) == 0:
            answer = BotMessage.tracked.value.format(link=get_folder_url(result.data[0]),
                                                     upc_link=BotMessage.upc_table.value.format(link=result.data[1].get_link())
                                                     if result.data[1] is not None else
                                                     BotMessage.upc_table_unset.value,
                                                     tables=BotMessage.empty_tracked.value)
        else:
            answer = BotMessage.tracked.value.format(link=get_folder_url(result.data[0]),
                                                     upc_link=BotMessage.upc_table.value.format(link=result.data[1].get_link())
                                                     if result.data[1] is not None else
                                                     BotMessage.upc_table_unset.value,
                                                     tables=BotMessage.br.value.join([
                                                         BotMessage.table.value.format(
                                                             id=table.id,
                                                             name=table.google_table_id,
                                                             link=table.get_link()
                                                         ) for table in result.data[2]
                                                     ])) + BotMessage.remove_tracked.value
    else:
        answer = result.message

    await msg.answer(answer, disable_web_page_preview=True)


@tables_router.message(Command("add_tracked"))
async def add_tracked_table_handler(msg: Message, command: CommandObject):
    chat_id = msg.chat.id
    user_id = msg.from_user.id
    unformat_link = command.args
    spreadsheet_id = extract_spreadsheet_id(unformat_link)

    if spreadsheet_id is None:
        answer = BotMessage.unsupported_link.value
    else:
        result = add_table(chat_id, user_id, spreadsheet_id)

        if result.success:
            answer = BotMessage.tracked.value.format(link=get_folder_url(result.data[0]),
                                                     upc_link=BotMessage.upc_table.value.format(link=result.data[1].get_link())
                                                     if result.data[1] is not None else
                                                     BotMessage.upc_table_unset.value,
                                                     tables=BotMessage.br.value.join([
                                                         BotMessage.table.value.format(
                                                             id=table.id,
                                                             name=table.google_table_id,
                                                             link=table.get_link()
                                                         ) for table in result.data[2]
                                                     ])) + BotMessage.remove_tracked.value
        else:
            answer = result.message

    await msg.answer(answer, disable_web_page_preview=True)


@tables_router.message(Command("remove_tracked"))
async def remove_tracked_table_handler(msg: Message, command: CommandObject):
    chat_id = msg.chat.id
    user_id = msg.from_user.id
    table_id = command.args

    if table_id is None:
        answer = BotMessage.empty_table_id.value
    else:
        try:
            table_id = int(table_id)
            result = remove_table(chat_id, user_id, table_id)

            if result.success:
                if len(result.data[2]) != 0:
                    answer = BotMessage.tracked.value.format(link=get_folder_url(result.data[0]),
                                                             upc_link=BotMessage.upc_table.value.format(link=result.data[1].get_link())
                                                             if result.data[1] is not None else
                                                             BotMessage.upc_table_unset.value,
                                                             tables=BotMessage.br.value.join([
                                                                 BotMessage.table.value.format(
                                                                     id=table.id,
                                                                     name=table.google_table_id,
                                                                     link=table.get_link()
                                                                 ) for table in result.data[2]
                                                             ])) + BotMessage.remove_tracked.value
                else:
                    answer = BotMessage.tracked.value.format(link=get_folder_url(result.data[0]),
                                                             upc_link=BotMessage.upc_table.value.format(link=result.data[1].get_link())
                                                             if result.data[1] is not None else
                                                             BotMessage.upc_table_unset.value,
                                                             tables=BotMessage.empty_tracked.value)
            else:
                answer = result.message
        except ValueError:
            answer = BotMessage.unsupported_table_id.value

    await msg.answer(answer, disable_web_page_preview=True)
