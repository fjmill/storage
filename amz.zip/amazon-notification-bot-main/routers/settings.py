from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from enums import BotMessage

settings_router = Router()


@settings_router.message(Command('help'))
async def help_handler(msg: Message):
    await msg.answer(BotMessage.help.value)
