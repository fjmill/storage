import os.path

from aiohttp import web
from dotenv import load_dotenv

import asyncio
import logging

from data_types import GoogleTable
from enums import BotMessage
from misc import bot, dp, app


async def main():
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


async def start_web_app():
    app.router.add_post('/notify', notify_handler)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, '0.0.0.0', 8080)
    await site.start()


async def notify_handler(request):
    chats = (await request.json())['chats']
    print(chats)

    for chat in chats:
        chat_id = chat['id']
        tables = chat['tables']
        need_upc_check = chat['need_upc_checking']
        unsetted_upc = chat['unsetted_upc']

        await bot.send_message(chat_id, BotMessage.notification.value)

        for table in tables:
            await bot.send_message(chat_id, BotMessage.checked_table.value.format(
                id=table['table_number'],
                name=table['table_id'],
                link=GoogleTable.get_link_from_id(table['table_id']),
                broken=BotMessage.br.value.join([
                    BotMessage.broken_asin.value.format(
                        asin=fail['asin'],
                        link=fail.get('link'),
                        required=fail['required'],
                        real=fail['real'],
                        status={
                            0: BotMessage.asin_fixed.value,
                            1: BotMessage.asin_template_missing.value,
                            2: BotMessage.asin_template_broken.value,
                            3: BotMessage.not_enough_upc.value
                        }.get(fail['success'], "")
                    ) for fail in table['failed']
                ]),
            ), disable_web_page_preview=True)

        if need_upc_check:
            await bot.send_message(chat_id, BotMessage.need_more_upc.value)

        if unsetted_upc:
            await bot.send_message(chat_id, BotMessage.upc_table_unset.value)

    return web.Response(text="Сообщение успешно отправлено!")


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    loop = asyncio.get_event_loop()
    loop.create_task(main())
    loop.create_task(start_web_app())
    loop.run_forever()
