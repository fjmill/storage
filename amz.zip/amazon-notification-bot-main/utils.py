import os
import re
from typing import List, Tuple

import requests

from data_types import Response, GoogleTable
from enums import BotMessage, Route


def get_url(api_route: Route, **search_params) -> str:
    search = '&'.join(map(lambda i: f'{i[0]}={i[1]}', search_params.items()))
    return f'{os.getenv("SERVER_URL")}{api_route.value}{f"?{search}" if search != "" else ""}'


def get_folder_url(folder_id: str) -> str:
    return f"{os.getenv('GOOGLE_DRIVE_URL')}{folder_id}"


def extract_spreadsheet_id(link: str):
    if link is None:
        return None

    # Удаление лишних пробелов в начале и в конце строки
    link = link.strip()

    # Проверка, что строка является ссылкой на Google Sheets
    if link.startswith("https://docs.google.com/spreadsheets/d/"):
        pattern = r'/spreadsheets/d/([a-zA-Z0-9-_]+)'
        match = re.search(pattern, link)
        if match:
            return match.group(1)

    # Если ссылка недействительна или не найдена, возвращаем None
    return None


def parse_chat_info(response) -> Response[Tuple[str, GoogleTable, List[GoogleTable]]]:
    json_data = response.json()
    chat = json_data['chat']
    tables_data = json_data.get("tables", [])
    tables = [GoogleTable(**table) for table in tables_data]
    return Response.ok(data=(
        chat['folder_id'],
        None if chat['upc_table_id'] is None else GoogleTable(-1, chat['upc_table_id']),
        tables))


def register_group(chat_id: int, chat_type: str, user_id: int) -> Response:
    response = requests.post(
        get_url(Route.register),
        json={
            'chat_id': chat_id,
            'type': chat_type,
            'user_id': user_id
        }
    )

    if response.ok:
        return Response(True, message=BotMessage.registered.value)
    else:
        if response.status_code == 403:
            return Response.error(BotMessage.already_registered.value)
        else:
            return Response.error(BotMessage.wrong_register.value)


def unregister_group(chat_id: int, user_id: int) -> Response:
    response = requests.post(
        get_url(Route.unregister),
        json={
            'chat_id': chat_id,
            'user_id': user_id
        }
    )

    if response.ok:
        return Response(True, message=BotMessage.unregistered.value)
    else:
        if response.status_code == 403:
            return Response.error(BotMessage.not_enough_rights.value)
        elif response.status_code == 404:
            return Response.error(BotMessage.not_registered.value)
        else:
            return Response.error(BotMessage.wrong_cancel_register.value)


def get_tracked_tables(chat_id: int) -> Response[Tuple[str, GoogleTable, List[GoogleTable]]]:
    print(get_url(Route.tracked_tables, chat_id=chat_id))

    response = requests.get(
        get_url(Route.tracked_tables, chat_id=chat_id)
    )

    if response.ok:
        return parse_chat_info(response)
    else:
        if response.status_code == 404:
            return Response.error(BotMessage.not_registered.value)
        else:
            return Response.error(BotMessage.wrong_tracked.value)


def add_table(chat_id: int, user_id: int, table: str) -> Response[Tuple[str, GoogleTable, List[GoogleTable]]]:
    print(get_url(Route.add_table))

    response = requests.post(
        get_url(Route.add_table),
        json={
            'chat_id': chat_id,
            'user_id': user_id,
            'table_id': table
        }
    )

    if response.ok:
        return parse_chat_info(response)
    else:
        if response.status_code == 423:
            error = response.json()
            return Response.error(BotMessage.bad_table_id.value.format(id=table, email=error['email']))
        elif response.status_code == 403:
            return Response.error(BotMessage.not_enough_rights.value)
        elif response.status_code == 404:
            return Response.error(BotMessage.not_registered.value)
        elif response.status_code == 409:
            return Response.error(BotMessage.already_tracked.value.format(id=table))
        else:
            return Response.error(BotMessage.wrong_tracked.value)


def remove_table(chat_id: int, user_id: int, table_id: int) -> Response[Tuple[str, GoogleTable, List[GoogleTable]]]:
    print(get_url(Route.remove_table))

    response = requests.post(
        get_url(Route.remove_table),
        json={
            'chat_id': chat_id,
            'user_id': user_id,
            'table_id': table_id
        }
    )

    if response.ok:
        return parse_chat_info(response)
    else:
        if response.status_code == 403:
            return Response.error(BotMessage.not_enough_rights.value)
        elif response.status_code == 404:
            return Response.error(BotMessage.not_registered.value)
        elif response.status_code == 409:
            return Response.error(BotMessage.not_tracked.value.format(id=table_id))
        else:
            return Response.error(BotMessage.wrong_tracked.value)


def set_upc_table(chat_id: int, user_id: int, table: str) -> Response[Tuple[str, GoogleTable, List[GoogleTable]]]:
    response = requests.post(
        get_url(Route.upc_table),
        json={
            'chat_id': chat_id,
            'user_id': user_id,
            'table_id': table
        }
    )

    if response.ok:
        return parse_chat_info(response)
    else:
        if response.status_code == 423:
            error = response.json()
            return Response.error(BotMessage.bad_table_id.value.format(id=table, email=error['email']))
        elif response.status_code == 403:
            return Response.error(BotMessage.not_enough_rights.value)
        elif response.status_code == 404:
            return Response.error(BotMessage.not_registered.value)
        elif response.status_code == 409:
            return Response.error(BotMessage.already_tracked.value.format(id=table))
        else:
            return Response.error(BotMessage.wrong_tracked.value)


def remove_upc_table(chat_id: int, user_id: int) -> Response[Tuple[str, GoogleTable, List[GoogleTable]]]:
    response = requests.delete(
        get_url(Route.upc_table),
        json={
            'chat_id': chat_id,
            'user_id': user_id
        }
    )

    if response.ok:
        return parse_chat_info(response)
    else:
        if response.status_code == 403:
            return Response.error(BotMessage.not_enough_rights.value)
        elif response.status_code == 404:
            return Response.error(BotMessage.not_registered.value)
        elif response.status_code == 409:
            return Response.error(BotMessage.upc_table_unset.value)
        else:
            return Response.error(BotMessage.wrong_tracked.value)
