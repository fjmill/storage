import os

from aiogram import Bot, Dispatcher
from aiogram.enums.parse_mode import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiohttp import web
from dotenv import load_dotenv

from routers import auth_router, admins_router, tables_router, upc_router
from routers.settings import settings_router

print("misc.py 1", os.getenv("BOT_TOKEN"))
load_dotenv(os.path.join(os.getcwd(), ".env"))
print("misc.py 2", os.getenv("BOT_TOKEN"))

app = web.Application()
bot = Bot(token=os.getenv('BOT_TOKEN'), parse_mode=ParseMode.HTML)
dp = Dispatcher(storage=MemoryStorage())
dp.include_router(auth_router)
dp.include_router(admins_router)
dp.include_router(tables_router)
dp.include_router(upc_router)
dp.include_router(settings_router)