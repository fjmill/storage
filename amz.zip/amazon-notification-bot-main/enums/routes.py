from enum import Enum


class Route(Enum):
    register = "/auth/register_group"
    unregister = "/auth/unregister_group"
    upc_table = "/upc"
    tracked_tables = "/track/tracked"
    add_table = "/track/add_table"
    remove_table = "/track/remove_table"
    templates = "/upload/{group_id}"
    upload_template = "/upload/{group_id}"
    delete_all_templates = "/upload/{group_id}"
    get_template = "/upload/{group_id}/{template_name}"
    delete_template = "/upload/{group_id}/{template_name}"
